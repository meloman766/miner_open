export const givers100 = [
    { address: 'EQAHKQ157ZfeV2hqZ_EhR9_sjKr6AW-x15LxKp3F8jWkQCRv', reward: 100 },
    { address: 'EQCAGbUzkfXA-_k5WKuH3r0ERlk0X70_aHxHF3QxO4c7xzIc', reward: 100 },
    { address: 'EQBzh8zKTIglDKo4oNuTANGHAB3cPzrqz8jzxBX7t6lraCFB', reward: 100 },
    { address: 'EQDYkDO-B9RVj5JtraUuQi6-z_UZBUy76NkK-GVMxQR-nbC6', reward: 100 },
    { address: 'EQBRpj30zjeeZx2uBNwkxf0N2umd4Zx939l4B7ZWgLMrHw6o', reward: 100 },
    { address: 'EQDD6XMM8KjLqCQQUaW2MT3zif7Co6b1uvm7zea91NRmG6DU', reward: 100 },
    { address: 'EQBlZKR1SdUH021RHD9mSjGwolg6v2WAeh4H3B55btxLFHSY', reward: 100 },
    { address: 'EQDbBsBdFQoQr-PQrOHA6diZJLeBIARqH-IdMTPN0kZePEhr', reward: 100 }, // 100
]

export const givers200 = [
    { address: 'EQAxcQR1ZATipq7_p3uC_nzdAGfEI9_ot7KwbImmZUcF28Fv', reward: 200 },
    { address: 'EQCKI-brKDH7yB_ZNtLBQuH5WHxhVyTZ8TTMeczM90MTb4BR', reward: 200 },
    { address: 'EQCqbXeTPH27h6PCxW9siLd99TK6V_1z_Qd4ZvK2epOYXJ13', reward: 200 },
    { address: 'EQCMLOxANELISfDOOs-4ajGkl87jPJF23-jx_q3WZcqABt_M', reward: 200 },
    { address: 'EQA0cEVAzvBCJRIRAE-0rJTBRj62iI_uhoERg8U2ils9U0TP', reward: 200 },
    { address: 'EQAxd4JnIJeiYjhjx5oVCfy7zIz90lsEPX55cJPAZfT_nOPn', reward: 200 },
    { address: 'EQBRfSLLWKpPENVrplO6cgF-YCXT5-KDTJlYTzijziqBc69X', reward: 200 },
    { address: 'EQCBQwfxN3osQrIQaDS2I6hKgt-V6pzC-in56E_SyupI0_xv', reward: 200 },
    { address: 'EQBJ2X9VBfvBsoMfQFYFRmQW4reXOK4fqYxvSqw5PrY0Okyd', reward: 200 },
    { address: 'EQAwYPZEypqBGNa2KjthhWErg2R4CFrgPk25SrEYqZ0KNxYB', reward: 200 }, // 200
]

export const givers1000 = [
    { address: 'EQAXkmHPHj38EAoSUpFS4h_-51Nr-0zkt-WvqFz-g9EeyytS', reward: 1000 },
    { address: 'EQCgIz9n-IKjCnkp1cvdY_Y36hWrspYyn-YzwtnWRAO3VX-2', reward: 1000 },
    { address: 'EQCaC2SnsYdFwBKxmVNDDzErdwIuE6jCFQ_vktkMEgJvnE3q', reward: 1000 },
    { address: 'EQBa2MAvh8B4wGRGSCL6KauYRURMDvnhyJnOFe0AS_mY8pVy', reward: 1000 },
    { address: 'EQCJS7stH6ArCx9rMKqW6ma3wwnQ8jIZseZSomfIe4Xu7bTh', reward: 1000 },
    { address: 'EQBgYOXP1jher0Ryi8Eu0JdCSGQyJXq5iBk02Fot0fOo_Jq6', reward: 1000 },
    { address: 'EQCYhHyUdcM-cY-52ajaKn_W_WQ1eiDZi5_MmJLhQYVYlroa', reward: 1000 },
    { address: 'EQCgvetY70xTWBebiW0eqk85d8M7nafRd7IPAck7QVnecnE0', reward: 1000 },
    { address: 'EQCJSX9yLJOXX7jVGpnsFneV-0w2ViSsyqmtrAtMZRAJP9_X', reward: 1000 },
    { address: 'EQBE4Xu0kyHAN3zKmdrgxQmpMoAYuEsJECPM40PV2Sa6nq1j', reward: 1000 }, // 1 000
]

export const givers5000 = [
    { address: 'EQCpdH9Ly5YzKQvyLvgdpQn8sAa72Q88ChG5Hzy_-bk-OFFz', reward: 5000 },
    { address: 'EQCf2CHBldCQBRKmgy7S17Hjid2mom9bKiVHf3YAhSpnboHj', reward: 5000 },
    { address: 'EQBvTXPQdUFTwDOxdI6DK4tFwlyL0dYtFEkxoq-dsMeOlbQ-', reward: 5000 },
    { address: 'EQDwENdKtFQ8Epl6d6Y2g_0QnAPPzNpGnDSy8FJwRUSJs0Ta', reward: 5000 },
    { address: 'EQA9w-G3wPvo7t3OnggaG8rqzpdjiuGka-Nd4hoCPV1_BwWI', reward: 5000 },
    { address: 'EQBnSDj00PPIb_I2IosTwefIV4OJQqElZAXwufX1nHlqH-at', reward: 5000 },
    { address: 'EQCMF2xRfeKNGreAZ8w5237Rf6Rlrp3in5Wmf7nDVB6hAfwU', reward: 5000 },
    { address: 'EQD8ZchOWgQxbGWLXMUb_DhCkcw9mrJgCmZyHd18UmCVdm8T', reward: 5000 },
    { address: 'EQDLSjsUUCIgFEAxdtJYUbzNPvenpTTXoZjIQqmHWXQ-kBSX', reward: 5000 },
    { address: 'EQAahx1pXEI0Gmq1hCQrLh0vVFTRVpGgiRHz_088hzQuEr9x', reward: 5000 }, // 5 000
]

export const givers10000 = [
    { address: 'EQAY4LHfgqInZTekX9SDBmbBimShl3OdmTnQGSw82DQBNKAQ', reward: 10000 },
    { address: 'EQCfPVHTaKwoPOG5C8jSrhi5j82EuhNdKqoirEPvES8igPPN', reward: 10000 },
    { address: 'EQB6P_39LCqDIcZ600Y6qenlc47a-FtjpReb4rCHGZOt8b2q', reward: 10000 },
    { address: 'EQDftSo4Mn53jyUFb5bTzmJevxUjK832iy6Tt4eoYIB9M7J5', reward: 10000 },
    { address: 'EQCXsac0FpvNyQwZSCImpmh1O8QWa-JSnal2ESYXZaKq9twn', reward: 10000 },
    { address: 'EQDavF_H1EBBsQ82HdyvCExFRbFKQ3mpsHMElE0wbim5ehHM', reward: 10000 },
    { address: 'EQB-Tc3OrKn__jSa9hTPEmbMioOQN08Fvda_85exIB4GPw4g', reward: 10000 },
    { address: 'EQAl3C0k1R8X9Ms7VG4cUpM3u_lKqfKIgYCLjMDMqaiwXynW', reward: 10000 },
    { address: 'EEQCHODQyANmzftrcaGUOctE_D7XSEZKTepzxXyGLA6dZNDTJ', reward: 10000 },
    { address: 'EQDCeae9X_DZji0GEUXV8IFX5BPID2AX8zVCxugeH_H1fb9Z', reward: 10000 }, // 10 000
]
